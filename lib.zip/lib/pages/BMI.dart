import 'package:flutter/material.dart';

class BMI extends StatefulWidget {
  BMI({key}) : super(key: key);

  State<BMI> createState() => _BMIState();
}

class _BMIState extends State<BMI> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("BMI"),
      ),
    );
  }
}
