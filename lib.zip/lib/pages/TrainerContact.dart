import 'package:flutter/material.dart';

class TrainerContact extends StatefulWidget {
  TrainerContact({key}) : super(key: key);

  @override
  State<TrainerContact> createState() => _TrainerContactState();
}

class _TrainerContactState extends State<TrainerContact> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Trainers Contact")),
    );
  }
}
