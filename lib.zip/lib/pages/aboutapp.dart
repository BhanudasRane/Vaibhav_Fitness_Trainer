import 'package:flutter/material.dart';

class AboutApp extends StatefulWidget {
  AboutApp({key}) : super(key: key);

  @override
  State<AboutApp> createState() => _AboutAppState();
}

class _AboutAppState extends State<AboutApp> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("About This Application"),
      ),
      body: Card(
        child: Container(
          color: Colors.red[300],
          child: Text("Developed by........kbtcoe students  "),
        ),
      ),
    );
  }
}
