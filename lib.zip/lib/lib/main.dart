import 'package:erp_project/staff/staff_dashboard.dart';
import 'package:erp_project/staff/staff_login.dart';
import 'package:erp_project/staff/staff_notification.dart';
import 'package:erp_project/student/onboardscreen/onboardingscreen.dart';
import 'package:erp_project/student/student_login.dart';
import 'package:erp_project/student/student_notification.dart';
import 'package:erp_project/student/student_profile.dart';
import 'package:flutter/material.dart';

import 'splashscreen.dart';
import 'student/student_dashboard.dart';

// import 'student/student_dashboard.dart';
// import 'student/login.dart';
// import 'student/signup.dart';
// import 'splashscreen.dart';

const String SplashRoute = "/mysplash";
const String LoginRoute = "/login";
const String StaffLoginRoute = "/stafflogin";
const String StudentHomeRoute = "/studethome";
const String StaffHomeRoute = "/staffhome";
const String StudentProfileRoute = "/profile";
const String StaffNotificationRoute = "/staffnotification";
const String NotificationRoute = "/notification";

const String OnboardScreenRoute = "/onboardingscreen";
// const String SignupRoute = "/signup";
// const String StudentProfileRoute = "/student_profile";
void main() async {
  // WidgetsFlutterBinding.ensureInitialized();
  // await Firebase.initializeApp();
  runApp(
    MaterialApp(
      debugShowCheckedModeBanner: false,
      initialRoute: SplashRoute,
      routes: {
        SplashRoute: (context) => Splash(),

        LoginRoute: (context) => Student_Login(),
        StaffLoginRoute: (context) => Staff_Login(),
        StudentHomeRoute: (context) => StudentHome(),
        StaffHomeRoute: (context) => StaffHome(),
        StaffNotificationRoute: (context) => StaffNotifPage(),
        OnboardScreenRoute: (context) => OnboardingScreen(),
        // HomeRoute: (context) => StaffProfilePage(),
        // NotificationRoute: (context) => NotifPage(),
        // SignupRoute: (context) => SignUp(),
        // StudentProfileRoute: (context) => ProfilePage(),
      },
    ),
  );
}
