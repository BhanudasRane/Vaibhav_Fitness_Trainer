import 'package:erp_project/Widgets/DashboardCards.dart';
import 'package:erp_project/Widgets/UserDetailCard.dart';
import 'package:erp_project/api/api.dart';
import 'package:erp_project/main.dart';
import 'package:erp_project/services/sharedpreference.dart';
import 'package:erp_project/student/Attendance/Attendance.dart';
import 'package:erp_project/student/Exam/Exam_Rseult.dart';
import 'package:erp_project/student/Exam/Result.dart';
import 'package:erp_project/student/Leave_Apply/Leave_apply.dart';
import 'package:erp_project/student/student_notification.dart';
import 'package:erp_project/student/student_profile.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

// import '../Widgets/userdetail.dart';

import '../Widgets/AppBar.dart';
import '../Widgets/BouncingButton.dart';

class StaffHome extends StatefulWidget {
  const StaffHome({Key? key}) : super(key: key);

  @override
  State<StaffHome> createState() => _StaffHomeState();
}

Map<String, dynamic> details = {};

class _StaffHomeState extends State<StaffHome>
    with SingleTickerProviderStateMixin {
  late Animation animation, delayedAnimation, muchDelayedAnimation, LeftCurve;
  late AnimationController animationController;

  @override
  void initState() {
    // TODO: implement initState

    super.initState();
    Firebase.initializeApp();
    SystemChrome.setEnabledSystemUIOverlays([]);
    animationController =
        AnimationController(duration: Duration(seconds: 3), vsync: this);
    animation = Tween(begin: -1.0, end: 0.0).animate(CurvedAnimation(
        parent: animationController, curve: Curves.fastOutSlowIn));

    delayedAnimation = Tween(begin: -1.0, end: 0.0).animate(CurvedAnimation(
        parent: animationController,
        curve: Interval(0.5, 1.0, curve: Curves.fastOutSlowIn)));

    muchDelayedAnimation = Tween(begin: -1.0, end: 0.0).animate(CurvedAnimation(
        parent: animationController,
        curve: Interval(0.8, 1.0, curve: Curves.fastOutSlowIn)));

    LeftCurve = Tween(begin: -1.0, end: 0.0).animate(CurvedAnimation(
        parent: animationController,
        curve: Interval(0.5, 1.0, curve: Curves.easeInOut)));
  }

  @override
  void dispose() {
    // TODO: implement dispose
    animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final UserCardService _userService = UserCardService();

    _userService.readCache();

    print("In widget ");
    print(kbtug);
    print(id);
    print(name);
    print(dob);
    print(academic_year);

    final PrefService _prefService = PrefService();
    _prefService.readCache();

    print("In widget ");
    print(kbtug);
    print("End In widget");
    final student_profile = Student_Profile_Api(kbtug);

    print("this is ca");
    // print(ca);
    print("end");
    final double width = MediaQuery.of(context).size.width;
    final double height = MediaQuery.of(context).size.height;

    animationController.forward();
    return AnimatedBuilder(
      animation: animationController,
      builder: (BuildContext context, Widget? child) {
        final GlobalKey<ScaffoldState> _scaffoldKey =
            new GlobalKey<ScaffoldState>();
        return Scaffold(
          key: _scaffoldKey,
          // drawer: Drawer(
          //   elevation: 0,
          //   child: MainDrawer(),
          // ),
          appBar: CommonAppBar(
            menuenabled: false,
            notificationenabled: true,
            ontap: () {},
            title: "Student Dashboard",
          ),
          body: ListView(
            children: [
              UserDetailCard(
                id: id.toString(),
                name: name.toString(),
                dob: dob.toString(),
                academic_year: academic_year.toString(),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(30.0, 10, 30, 10),
                child: Container(
                  alignment: Alignment(1.0, 0),
                  child: Padding(
                    padding: const EdgeInsets.only(top: 10.0, right: 20.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Transform(
                          transform: Matrix4.translationValues(
                              muchDelayedAnimation.value * width, 0, 0),
                          child: Bouncing(
                            onPress: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        Attendance(),
                                  ));
                            },
                            child: DashboardCard(
                              name: "Exam",
                              imgpath: "exam.png",
                            ),
                          ),
                        ),
                        Transform(
                          transform: Matrix4.translationValues(
                              delayedAnimation.value * width, 0, 0),
                          child: Bouncing(
                            onPress: () {},
                            child: DashboardCard(
                              name: "TimeTable",
                              imgpath: "calendar.png",
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(30.0, 10, 30, 10),
                child: Container(
                  alignment: Alignment(1.0, 0),
                  child: Padding(
                    padding: const EdgeInsets.only(top: 10.0, right: 20.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Transform(
                          transform: Matrix4.translationValues(
                              muchDelayedAnimation.value * width, 0, 0),
                          child: Bouncing(
                            onPress: () {},
                            child: DashboardCard(
                              name: "Library",
                              imgpath: "library.png",
                            ),
                          ),
                        ),
                        Transform(
                          transform: Matrix4.translationValues(
                              delayedAnimation.value * width, 0, 0),
                          child: Bouncing(
                            onPress: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        LeaveApply(),
                                  ));
                            },
                            child: DashboardCard(
                              name: "Apply Leave",
                              imgpath: "leave_apply.png",
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.fromLTRB(30.0, 10, 30, 10),
                child: Container(
                  alignment: Alignment(1.0, 0),
                  child: Padding(
                    padding: const EdgeInsets.only(top: 10.0, right: 20.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Transform(
                          transform: Matrix4.translationValues(
                              muchDelayedAnimation.value * width, 0, 0),
                          child: Bouncing(
                            onPress: () async {
                              await _userService.removeCache(
                                  'id', "name", "dob", "academic_year");
                              await _prefService
                                  .removeCache("kbtid")
                                  .whenComplete(() {
                                Navigator.of(context).pushNamed(LoginRoute);
                              });
                            },
                            child: const DashboardCard(
                              name: "Logout",
                              imgpath: "logout.png",
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

// class StudentHome extends StatefulWidget {
//   @override
//   State<StudentHome> createState() => _StudentHomeState();
// }
