import 'dart:convert';
import 'package:erp_project/api/semmodal/sem.dart';
import 'package:flutter/material.dart';

import 'package:http/http.dart' as http;

class Semwise_Result_Api with ChangeNotifier {
  late String id;

  Map<String, List> semdetails = {};

  // late String name;
  // late String dob;
  // late String academic_year;
  // late String sex;
  // late String per_phone_no;
  // late String email;R
  // late String admission_date;
  String kbtugg = "";
  var _rlist = [];
  Semwise_Result_Api(kbtug) {
    print("Semwise_Result_Api@@@s");
    print(kbtug);
    print("Semwise_Result_Api@@@s");

    kbtugg = kbtug;
    this.fetchSemwiseResult();
  }

  List get cgpa_data {
    return [..._rlist];
  }

  get ItemCategoryModel => null;
  // List<Todo> _todos = [];

  // List<Todo> get todos {
  //   return [..._todos];
  // }

  fetchSemwiseResult() async {
    print("Semwise_Result_ApiKbtug in api ");
    print(kbtugg);
    final r = await http.get(
        Uri.http("192.168.43.126:8000", "/user/student/sgpa/" + kbtugg + "/"));
    // final url = 'http://192.168.43.126:8000/apis/v1/?format=json';
    // final response = await http.get(r);
    print(" r = ");
    print(r);
    print("r.body =");
    print(r.body);
    print("r type= ");
    print(r.runtimeType);
    print("r.body type= ");
    print(r.body.runtimeType);
    print("a");
    // var a = r.body;
    // print(a.runtimeType);

    print("app runtype");
    if (r.statusCode == 200) {
      List<dynamic> data = jsonDecode(r.body);
      List<Sem> sems = data.map((data) => Sem.fromJson(data)).toList();
      print(sems[0].EM0REF);
      _rlist = semdetails.values.toList();
      print("rlist****************************************");

      print(_rlist);
      print("rlistenf****************************************");

      notifyListeners();
    }
    // details = json.decode(r.body);
    // _list = details.values.toList();
  }
}

class Student_Profile_Api with ChangeNotifier {
  Map<String, dynamic> details = {};
  late String id;
  late String name;
  late String dob;
  late String academic_year;
  late String sex;
  late String per_phone_no;
  late String email;
  late String admission_date;
  String kbtugg = "";
  var _list = [];
  Student_Profile_Api(kbtug) {
    print("@@@s");
    print(kbtug);
    print("@@@s");

    kbtugg = kbtug;
    this.fetchProfile();
  }

  List get student_data {
    return [..._list];
  }
  // List<Todo> _todos = [];

  // List<Todo> get todos {
  //   return [..._todos];
  // }

  fetchProfile() async {
    print("Kbtug in api ");
    print(kbtugg);
    final r = await http
        .get(Uri.http("192.168.43.126:8000", "/user/student/" + kbtugg + "/"));
    // final url = 'http://192.168.43.126:8000/apis/v1/?format=json';
    // final response = await http.get(r);

    if (r.statusCode == 200) {
      details = json.decode(r.body);
      // print("****************************************");
      print(details);
      // print("****************************************");

      _list = details.values.toList();

      // print("****************************************");

      print(_list);
      // print("****************************************");

      notifyListeners();
    }
    // details = json.decode(r.body);
    // _list = details.values.toList();
  }

  // void addTodo(Todo todo) async {
  //   final response = await http.post('http://192.168.43.126:8000/apis/v1/',
  //       headers: {"Content-Type": "application/json"}, body: json.encode(todo));
  //   if (response.statusCode == 201) {
  //     todo.id = json.decode(response.body)['id'];
  //     _todos.add(todo);
  //     notifyListeners();
  //   }
  // }

  // void deleteTodo(Todo todo) async {
  //   final response =
  //       await http.delete('http://192.168.43.126:8000/apis/v1/${todo.id}/');
  //   if (response.statusCode == 204) {
  //     _todos.remove(todo);
  //     notifyListeners();
  //   }
  // }

}

class Login_Api with ChangeNotifier {
  Map<String, dynamic> details = {};
  late String kbtid;
  late int password;

  // var _list = [];
  // Login_Api() {
  //   this.loginfetch();
  // }

  // List get student_data {
  //   return [..._list];
  // }
  // List<Todo> _todos = [];

  // List<Todo> get todos {
  //   return [..._todos];
  // }

  Future loginFetch(todo) async {
    final response = await http.post(
        Uri.parse('http://192.168.43.126:8000/studentlogin/'),
        headers: {"Content-Type": "application/json"},
        body: json.encode(todo));

    print(response);
    // return response;
    //   final response = await http.post('http://192.168.43.126:8000/apis/v1/',
    //       headers: {"Content-Type": "application/json"}, body: json.encode(todo));
    if (response.statusCode == 201) {
      // todo.id = json.decode(response.body)['id'];
      // _todos.add(todo);
      notifyListeners();
      return response;
    }
  }
}

class Staff_Login_Api with ChangeNotifier {
  Map<String, dynamic> details = {};
  late String empid;
  late int password;

  // var _list = [];
  // Login_Api() {
  //   this.loginfetch();
  // }

  // List get student_data {
  //   return [..._list];
  // }
  // List<Todo> _todos = [];

  // List<Todo> get todos {
  //   return [..._todos];
  // }

  Future loginFetch(todo) async {
    final response = await http.post(
        Uri.parse('http://192.168.43.126:8000/user/studentlogin/'),
        headers: {"Content-Type": "application/json"},
        body: json.encode(todo));

    print(response);
    // return response;
    //   final response = await http.post('http://192.168.43.126:8000/apis/v1/',
    //       headers: {"Content-Type": "application/json"}, body: json.encode(todo));
    if (response.statusCode == 201) {
      // todo.id = json.decode(response.body)['id'];
      // _todos.add(todo);
      notifyListeners();
      return response;
    }
  }
}
